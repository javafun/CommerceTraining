﻿/// <reference path="~/dojo-vsdoc.js" />
(function() {
    return {
        createUI: function (namingContainer, container, settings) {
            var self = this;
            self.languageKeys = '/Commerce/visitorgroups/customerpropertiescriterion/propertynamerequiredtext,/Commerce/visitorgroups/customerpropertiescriterion/fromdaterequiredtext,' +
                                '/Commerce/visitorgroups/customerpropertiescriterion/todaterequiredtext,/Commerce/visitorgroups/customerpropertiescriterion/registrationsourcerequiredtext,' +
								'/Commerce/visitorgroups/customerpropertiescriterion/countryrequiredtext,/Commerce/visitorgroups/customerpropertiescriterion/regionrequiedtext,' + 
                                '/Commerce/visitorgroups/customerpropertiescriterion/customergrouprequiredtext,/Commerce/visitorgroups/customerpropertiescriterion/addresspostalcoderequiedtext,' +
                                '/Commerce/visitorgroups/customerpropertiescriterion/staterequiredtext,/Commerce/visitorgroups/customerpropertiescriterion/requiredfromdateearlierthantodatetext';

            this.prototype.createUI.apply(this, arguments);
        },

        uiCreated: function (namingContainer, settings) {
            var self = this;

            self._initialize(namingContainer, settings);
        },

        //add validation errors for required fields
        validate: function (namingContainer) {
            fromDate = dijit.byId(namingContainer + 'FromDate');
            toDate = dijit.byId(namingContainer + 'ToDate');
            customerGroup = dijit.byId(namingContainer + 'CustomerGroup');
            registrationSource = dijit.byId(namingContainer + 'RegistrationSource');
            country = dijit.byId(namingContainer + 'Country');
            region = dijit.byId(namingContainer + 'Region');
            addressPostalCode = dijit.byId(namingContainer + 'AddressPostalCode');
            state = dijit.byId(namingContainer + 'State');

            var propertyNameRequiredText = this.translatedText['/Commerce/visitorgroups/customerpropertiescriterion/propertynamerequiredtext'];
            var fromDateRequiredText = this.translatedText['/Commerce/visitorgroups/customerpropertiescriterion/fromdaterequiredtext'];
            var toDateRequiredText = this.translatedText['/Commerce/visitorgroups/customerpropertiescriterion/todaterequiredtext'];
            var customerGroupRequiredText = this.translatedText['/Commerce/visitorgroups/customerpropertiescriterion/customergrouprequiredtext'];
            var countryRequiredText = this.translatedText['/Commerce/visitorgroups/customerpropertiescriterion/countryrequiredtext'];
            var registrationSourceRequiredText = this.translatedText['/Commerce/visitorgroups/customerpropertiescriterion/registrationsourcerequiredtext'];
            var regionRequiredText = this.translatedText['/Commerce/visitorgroups/customerpropertiescriterion/regionrequiedtext'];
            var addressPostalCodeRequiedText = this.translatedText['/Commerce/visitorgroups/customerpropertiescriterion/addresspostalcoderequiedtext'];
            var stateRequiredText = this.translatedText['/Commerce/visitorgroups/customerpropertiescriterion/staterequiredtext'];
            var fromDateLaterThanToDateText = this.translatedText['/Commerce/visitorgroups/customerpropertiescriterion/requiredfromdateearlierthantodatetext'];

            var ValidationError = dojo.require("epi-cms.form.ValidationError");
            var validationErrors = new ValidationError();

            var propertyName = dijit.byId(namingContainer + 'PropertyName');

            if (!propertyName.value || propertyName.value == '') {
                validationErrors.Add(propertyNameRequiredText, propertyName);
                return validationErrors;
            }

            switch (propertyName.value) {
                case 'birthdate':
                    if (!fromDate.value || fromDate.value == ''|| isNaN(fromDate.value.getTime())) {
                        validationErrors.Add(fromDateRequiredText, fromDate);
                    }
                    if (!toDate.value || toDate.value == '' || isNaN(toDate.value.getTime())) {
                        validationErrors.Add(toDateRequiredText, toDate);
                    }
                    if (fromDate.value > toDate.value) {
                        validationErrors.Add(fromDateLaterThanToDateText, toDate);
                    }
                    break;
                case 'customergroup':
                    if (!customerGroup.value || customerGroup.value == '') {
                        validationErrors.Add(customerGroupRequiredText, customerGroup);
                    }
                    break;
                case 'registrationsource':
                    if (!registrationSource.value || registrationSource.value == '') {
                        validationErrors.Add(registrationSourceRequiredText, registrationSource);
                    }
                    break;
                case 'country':
                    if (!country.value || country.value == '') {
                        validationErrors.Add(countryRequiredText, country);
                    }
                    break;
                case 'region':
                    if (!region.value || region.value == '') {
                        validationErrors.Add(regionRequiredText, region);
                    }
                    break;
                case 'addresspostalcode':
                    if (!addressPostalCode.value || addressPostalCode.value == '') {
                        validationErrors.Add(addressPostalCodeRequiedText, addressPostalCode);
                    }
                    break;
                case 'state':
                    if (!state.value || state.value == '') {
                        validationErrors.Add(stateRequiredText, state);
                    }
                    break;
                default:
                    break;
            }
            return validationErrors;
        },

        getSettings: function (namingContainer) {
            var propertyName = dijit.byId(namingContainer + 'PropertyName').value;
            var propertyValue = '';

            switch (propertyName) {
                case 'birthdate':
                    var fromDate = dojo.date.locale.format(dijit.byId(namingContainer + 'FromDate').value, { datePattern: "yyyy-MM-dd", selector: "date" });
                    var toDate = dojo.date.locale.format(dijit.byId(namingContainer + 'ToDate').value, { datePattern: "yyyy-MM-dd", selector: "date" });
                    propertyValue = fromDate + "|" + toDate;
                    break;
                case 'customergroup':
                    propertyValue = dijit.byId(namingContainer + 'CustomerGroup').value;
                    break;
                case 'registrationsource':
                    propertyValue = dijit.byId(namingContainer + 'RegistrationSource').value;
                    break;
                case 'country':
                    propertyValue = dijit.byId(namingContainer + 'Country').value;
                    break;
                case 'region':
                    propertyValue = dijit.byId(namingContainer + 'Region').value;
                    break;
                case 'addresspostalcode':
                    propertyValue = dijit.byId(namingContainer + 'AddressPostalCode').value;
                    break;
                case 'state':
                    propertyValue = dijit.byId(namingContainer + 'State').value;
                    break;
                default:
                    break;
            }

            return {
                PropertyName: propertyName,
                PropertyValue: propertyValue
            }
        },

        _initialize: function (namingContainer, settings) {
            var self = this;

            if (!settings) {
                settings = {};  // first time drop in dropzone
            }

            var _setBirthdateValues = function (namingContainer, birthdateValues) {
                var dates;

                if (birthdateValues) {
                    dates = birthdateValues.split("|");
                }

                if (dates && dates.length == 2) {
                    dijit.byId(namingContainer + 'FromDate').set('value', dates[0]);
                    dijit.byId(namingContainer + 'ToDate').set('value', dates[1]);
                } else {
                    dijit.byId(namingContainer + 'FromDate').set('value', null);
                    dijit.byId(namingContainer + 'ToDate').set('value', null); 
                }
            };

            var _updateInputControls = function (keyName, namingContainer, settings) {

                var _hideAllControls = function (namingContainer) {
                    dojo.style(dojo.byId(namingContainer + 'birthdateContainer'), 'display', 'none');
                    dojo.style(dojo.byId(namingContainer + 'customergroupContainer'), 'display', 'none');
                    dojo.style(dojo.byId(namingContainer + 'registrationsourceContainer'), 'display', 'none');
                    dojo.style(dojo.byId(namingContainer + 'countryContainer'), 'display', 'none');
                    dojo.style(dojo.byId(namingContainer + 'regionContainer'), 'display', 'none');
                    dojo.style(dojo.byId(namingContainer + 'addresspostalcodeContainer'), 'display', 'none');
                    dojo.style(dojo.byId(namingContainer + 'stateContainer'), 'display', 'none');
                };

                var _showControl = function (namingContainer, keyName, settings) {
                    dojo.style(dojo.byId(namingContainer + keyName + 'Container'), 'display', 'inline-block');
                    
                    // We need to special handle the date fields, as the default values from the server are not empty.
                    _setBirthdateValues(namingContainer, settings.PropertyValue);
                };

                _hideAllControls(namingContainer);
                _showControl(namingContainer, keyName, settings);
            };

            var _setControlValue = function (keyName, propertyValue) {
                if (!propertyValue || (propertyValue.length == 0)) {
                    return;
                }

                switch (keyName) {
                    case 'birthdate':
                        _setBirthdateValues(namingContainer, propertyValue);
                        break;
                    case 'customergroup':
                        dijit.byId(namingContainer + 'CustomerGroup').set('value', propertyValue);
                        break;
                    case 'registrationsource':
                        dijit.byId(namingContainer + 'RegistrationSource').set('value', propertyValue);
                        break;
                    case 'country':
                        dijit.byId(namingContainer + 'Country').set('value', propertyValue);
                        break;
                    case 'region':
                        dijit.byId(namingContainer + 'Region').set('value', propertyValue);
                        break;
                    case 'addresspostalcode':
                        dijit.byId(namingContainer + 'AddressPostalCode').set('value', propertyValue);
                        break;
                    case 'state':
                        dijit.byId(namingContainer + 'State').set('value', propertyValue);
                        break;
                    default:
                        break;
                }
            };

            var keySelectDijit = dijit.byId(namingContainer + 'PropertyName');

            _updateInputControls(keySelectDijit.value, namingContainer, settings);
            _setControlValue(keySelectDijit.value, settings.PropertyValue);

            var eventHandler = function () {
                _updateInputControls(keySelectDijit.value, namingContainer, settings);
            };

            dojo.connect(keySelectDijit, 'onChange', self, eventHandler);
        }
    }
})();