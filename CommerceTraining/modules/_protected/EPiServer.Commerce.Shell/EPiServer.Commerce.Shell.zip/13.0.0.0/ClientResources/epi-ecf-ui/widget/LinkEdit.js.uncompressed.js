require({cache:{
'url:epi-ecf-ui/widget/templates/LinkEdit.html':"﻿<div>\r\n    <div data-dojo-attach-point=\"toolbar\" data-dojo-type=\"epi-cms/contentediting/StandardToolbar\" class=\"epi-viewHeaderContainer epi-localToolbar\"></div>\r\n    <div data-dojo-attach-point=\"notificationBar\" data-dojo-type=\"epi-cms/contentediting/NotificationBar\" data-dojo-props=\"region:'top'\"></div>\r\n    <div data-dojo-type=\"dijit/layout/ContentPane\" data-dojo-attach-point=\"contentPane\" class=\"epi-view-container\">\r\n        <div data-dojo-type=\"epi-ecf-ui/contentediting/editors/CategoryCollectionEditor\" data-dojo-attach-point=\"categoryList\"></div>\r\n        <div data-dojo-attach-point=\"associationListNode\"></div>\r\n    </div>\r\n</div>"}});
﻿define("epi-ecf-ui/widget/LinkEdit", [
// dojo
    "dojo/_base/declare",

// dijit
    "dijit/_TemplatedMixin",
    "dijit/_WidgetsInTemplateMixin",

// EPi Framework
    "epi/shell/widget/_ModelBindingMixin",
    "epi/shell/TypeDescriptorManager",

// cms
    "epi-cms/widget/Breadcrumb",
    "epi-cms/widget/BreadcrumbCurrentItem",

// commerce
    "../contentediting/editors/CategoryCollectionEditor",
    "../contentediting/ModelSupport",
    "./_RelationViewBase",
// Resources
    "dojo/text!./templates/LinkEdit.html",
// Widgets in the template
    "epi-cms/contentediting/NotificationBar",
    "epi-cms/contentediting/StandardToolbar"
], function (
// dojo
    declare,

// dijit
    _TemplatedMixin,
    _WidgetsInTemplateMixin,

// EPi Framework
    _ModelBindingMixin,
    TypeDescriptorManager,

// CMS
    Breadcrumb,
    BreadcrumbCurrentItem,

// commerce
    CategoryCollectionEditor,
    ModelSupport,
    _RelationViewBase,
// Resources
    template
) {

    return declare([_RelationViewBase, _TemplatedMixin, _WidgetsInTemplateMixin, _ModelBindingMixin], {
        // summary:
        //    Represents the widget to edit relations and associations.
        // tags:
        //    public
        templateString: template,

        contentPane: this.contentPane,

        typeDescriptorManager: TypeDescriptorManager,

        updateView: function (data, context) {
            // summary:
            //		Updates the view, to reflect data changes.(when opening this view second time)
            // tags:
            //		protected

            this.inherited(arguments);
            this.set("value", context.id);
            this.resize();
        },


        _setValueAttr: function (value) {
            // summary:
            //      Sets value for this widget.
            // value: ContentReference
            //      Input content link to get data from.

            this.categoryList.set("value", value);
        }
    });
});
